import { Router } from 'express';
import { createWorkspaceController } from '../controllers/workspace.controller.js';

export function apiRouter(service) {
  const router = Router();
  const ctrl = createWorkspaceController(service);
  router.get('/health', (_req, res) => res.json({ ok: true, service: 'PolicyBoard API' }));
  router.get('/bootstrap', ctrl.bootstrap);
  router.post('/tasks', ctrl.createTask);
  router.patch('/tasks/:id', ctrl.updateTask);
  router.delete('/tasks/:id', ctrl.deleteTask);
  router.patch('/tests/:id', ctrl.updateTest);
  router.patch('/deliverables/:id', ctrl.updateDeliverable);
  router.get('/backup', ctrl.backup);
  router.post('/backup/import', ctrl.importBackup);
  router.post('/reset', ctrl.reset);
  return router;
}
