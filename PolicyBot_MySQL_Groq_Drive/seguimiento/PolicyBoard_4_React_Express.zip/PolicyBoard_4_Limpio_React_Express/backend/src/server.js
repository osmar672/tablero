import fs from 'node:fs/promises';
import { HOST, PORT, DATA_FILE, SEED_FILE } from './config/env.js';
import { jsonRepository } from './repositories/json.repository.js';
import { createWorkspaceService } from './services/workspace.service.js';
import { createApp } from './app.js';

const seed = JSON.parse(await fs.readFile(SEED_FILE, 'utf8'));
const repository = jsonRepository(DATA_FILE, seed);
await repository.init();
const app = createApp(createWorkspaceService(repository, seed));
app.listen(PORT, HOST, () => console.log(`PolicyBoard API: http://${HOST}:${PORT}/api/health`));
