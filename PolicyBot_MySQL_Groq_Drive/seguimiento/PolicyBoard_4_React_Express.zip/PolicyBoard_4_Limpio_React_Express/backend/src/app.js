import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { apiRouter } from './routes/index.js';
import { errorHandler, notFound } from './middlewares/error.middleware.js';
import { FRONTEND_DIST } from './config/env.js';

export function createApp(service) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '5mb' }));
  app.use('/api', apiRouter(service));
  if (fs.existsSync(path.join(FRONTEND_DIST, 'index.html'))) {
    app.use(express.static(FRONTEND_DIST));
    app.get('/{*path}', (_req, res) => res.sendFile(path.join(FRONTEND_DIST, 'index.html')));
  }
  app.use(notFound);
  app.use(errorHandler);
  return app;
}
