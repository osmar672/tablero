import { randomUUID } from 'node:crypto';

import { bad, string, taskPayload } from '../validators/task.validator.js';

export function createWorkspaceService(repository, originalSeed) {
  function state() { return repository.read(); }
  async function createTask(input) {
    return repository.mutate((draft) => {
      const value = taskPayload(input, draft.phases, { phase: input?.phase || 'preparacion' });
      const task = { ...value, id: `USR-${randomUUID().slice(0, 8).toUpperCase()}`, page: null,
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
      draft.tasks.unshift(task);
      return task;
    });
  }
  async function updateTask(id, input) {
    return repository.mutate((draft) => {
      const index = draft.tasks.findIndex((t) => t.id === id);
      if (index === -1) throw bad('Tarea no encontrada', 404);
      draft.tasks[index] = { ...taskPayload(input, draft.phases, draft.tasks[index]), updatedAt: new Date().toISOString() };
      return draft.tasks[index];
    });
  }
  async function deleteTask(id) {
    return repository.mutate((draft) => {
      const index = draft.tasks.findIndex((t) => t.id === id);
      if (index === -1) throw bad('Tarea no encontrada', 404);
      draft.tasks.splice(index, 1);
      return { deleted: true };
    });
  }
  async function updateTest(id, input) {
    return repository.mutate((draft) => {
      const test = draft.tests.find((x) => x.id === Number(id));
      if (!test) throw bad('Prueba no encontrada', 404);
      if (typeof input?.passed === 'boolean') test.passed = input.passed;
      if (typeof input?.note === 'string') test.note = string(input.note, 6000);
      return test;
    });
  }
  async function updateDeliverable(id, input) {
    return repository.mutate((draft) => {
      const item = draft.deliverables.find((x) => x.id === id);
      if (!item) throw bad('Entregable no encontrado', 404);
      if (typeof input?.done !== 'boolean') throw bad('Se necesita done: true/false');
      item.done = input.done;
      return item;
    });
  }
  function normalizeBackup(input) {
    if (!input || ![1, 2].includes(input.version) || !Array.isArray(input.tasks)
      || !Array.isArray(input.tests) || !Array.isArray(input.deliverables)) throw bad('El archivo no es un respaldo de PolicyBoard válido');
    if (input.tasks.length > 10000 || input.tests.length > 100 || input.deliverables.length > 100) throw bad('Respaldo demasiado grande');
    const seen = new Set();
    const tasks = input.tasks.map((task) => {
      if (!task || typeof task.id !== 'string' || task.id.length > 80 || seen.has(task.id)) throw bad('Identificadores de tarea incorrectos');
      seen.add(task.id);
      return { ...taskPayload(task, originalSeed.phases), id: task.id, page: task.page ?? null,
        createdAt: task.createdAt ?? null, updatedAt: task.updatedAt ?? null };
    });
    const tests = originalSeed.tests.map((test) => {
      const old = input.tests.find((x) => Number(x?.id) === test.id);
      return { ...test, passed: old?.passed === true, note: string(old?.note || '', 6000) };
    });
    const deliverables = originalSeed.deliverables.map((item) => {
      const old = input.deliverables.find((x) => x?.id === item.id);
      return { ...item, done: old?.done === true };
    });
    return { version: 2, phases: structuredClone(originalSeed.phases), tasks, tests, deliverables };
  }
  async function importBackup(input) {
    const normalized = normalizeBackup(input);
    await repository.mutate((draft) => Object.assign(draft, normalized));
    return { imported: true, tasks: normalized.tasks.length };
  }
  async function reset() {
    await repository.mutate((draft) => Object.assign(draft, structuredClone(originalSeed)));
    return { restored: true };
  }
  return { state, createTask, updateTask, deleteTask, updateTest, updateDeliverable, importBackup, reset };
}
