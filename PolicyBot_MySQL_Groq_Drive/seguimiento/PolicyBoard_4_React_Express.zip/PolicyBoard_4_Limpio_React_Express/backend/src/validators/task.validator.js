const STATUSES = ['todo', 'doing', 'blocked', 'done'];
const PRIORITIES = ['alta', 'media', 'baja'];
export const string = (value, max = 2000) => typeof value === 'string' ? value.trim().slice(0, max) : '';
export const bad = (message, code = 400) => Object.assign(new Error(message), { status: code });


export function taskPayload(input, phases, original = {}) {
    if (!input || typeof input !== 'object' || Array.isArray(input)) throw bad('Datos de tarea no válidos');
    const title = input.title === undefined ? original.title : string(input.title, 180);
    if (!title || title.length < 2) throw bad('El título debe tener al menos 2 caracteres');
    const phase = input.phase === undefined ? original.phase : input.phase;
    const priority = input.priority === undefined ? (original.priority || 'media') : input.priority;
    const status = input.status === undefined ? (original.status || 'todo') : input.status;
    if (!phases.some((p) => p.id === phase)) throw bad('Fase no válida');
    if (!PRIORITIES.includes(priority)) throw bad('Prioridad no válida');
    if (!STATUSES.includes(status)) throw bad('Estado no válido');
    const due = input.due === undefined ? (original.due || '') : string(input.due, 10);
    if (due && !/^\d{4}-\d{2}-\d{2}$/.test(due)) throw bad('Fecha no válida');
    let checklist = input.checklist === undefined ? (original.checklist || []) : input.checklist;
    if (!Array.isArray(checklist) || checklist.length > 100) throw bad('Lista de verificación no válida');
    checklist = checklist.map((item) => {
      if (!item || typeof item.text !== 'string') throw bad('Subtarea no válida');
      return { text: string(item.text, 280), done: item.done === true };
    }).filter((item) => item.text);
    return {
      ...original, title, phase, priority, status, due, checklist,
      description: input.description === undefined ? (original.description || '') : string(input.description, 8000),
      owner: input.owner === undefined ? (original.owner || '') : string(input.owner, 100),
      notes: input.notes === undefined ? (original.notes || '') : string(input.notes, 10000),
    };
  }
