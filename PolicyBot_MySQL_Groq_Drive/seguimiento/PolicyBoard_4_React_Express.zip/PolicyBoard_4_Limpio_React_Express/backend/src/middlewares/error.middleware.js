export function notFound(_req, res) { res.status(404).json({ error: 'Ruta no encontrada' }); }
export function errorHandler(error, _req, res, _next) {
  const status = error.status || (error.type === 'entity.too.large' ? 413 : 500);
  if (status >= 500) console.error(error);
  res.status(status).json({ error: status >= 500 ? 'Error interno del servidor' : error.message });
}
