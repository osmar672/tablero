import fs from 'node:fs/promises';
import path from 'node:path';

/** Un solo proceso escritor, con escritura atómica a disco.
 * Reemplazable por un repositorio PostgreSQL sin tocar rutas ni frontend.
 */
export function jsonRepository(file, seed) {
  let current;
  let queue = Promise.resolve();

  async function persist(data) {
    await fs.mkdir(path.dirname(file), { recursive: true });
    const temp = `${file}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`;
    try {
      await fs.writeFile(temp, JSON.stringify(data, null, 2), 'utf8');
      await fs.rename(temp, file);
    } catch (error) {
      await fs.rm(temp, { force: true }).catch(() => {});
      throw error;
    }
  }

  async function init() {
    if (current) return;
    try {
      current = JSON.parse(await fs.readFile(file, 'utf8'));
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
      current = structuredClone(seed);
      await persist(current);
    }
  }
  function read() {
    if (!current) throw new Error('El repositorio no está inicializado');
    return structuredClone(current);
  }
  function mutate(updater) {
    const operation = queue.then(async () => {
      const draft = read();
      const value = await updater(draft);
      draft.updatedAt = new Date().toISOString();
      await persist(draft);
      current = draft;
      return structuredClone(value ?? null);
    });
    queue = operation.catch(() => {}); // un error no bloquea las siguientes operaciones
    return operation;
  }
  return { init, read, mutate };
}
