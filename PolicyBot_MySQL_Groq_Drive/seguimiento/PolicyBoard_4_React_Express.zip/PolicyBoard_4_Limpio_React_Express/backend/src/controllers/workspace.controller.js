export function createWorkspaceController(service) {
  return {
    bootstrap: (_req, res) => res.json(service.state()),
    createTask: async (req, res) => res.status(201).json(await service.createTask(req.body)),
    updateTask: async (req, res) => res.json(await service.updateTask(req.params.id, req.body)),
    deleteTask: async (req, res) => res.json(await service.deleteTask(req.params.id)),
    updateTest: async (req, res) => res.json(await service.updateTest(req.params.id, req.body)),
    updateDeliverable: async (req, res) => res.json(await service.updateDeliverable(req.params.id, req.body)),
    backup: (_req, res) => {
      const json = JSON.stringify(service.state(), null, 2);
      res.setHeader('Content-Disposition', 'attachment; filename="policyboard-backup.json"');
      res.type('json').send(json);
    },
    importBackup: async (req, res) => res.json(await service.importBackup(req.body)),
    reset: async (req, res) => {
      if (req.body?.confirm !== true) return res.status(400).json({ error: 'Falta confirmación' });
      res.json(await service.reset());
    },
  };
}
