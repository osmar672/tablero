import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { jsonRepository } from '../src/repositories/json.repository.js';
import { createWorkspaceService } from '../src/services/workspace.service.js';

const dir = path.dirname(fileURLToPath(import.meta.url));
async function setup() {
  const location = await fs.mkdtemp(path.join(os.tmpdir(), 'policyboard-test-'));
  const seed = JSON.parse(await fs.readFile(path.resolve(dir, '../src/data/seed.json'), 'utf8'));
  const repo = jsonRepository(path.join(location, 'board.json'), seed);
  await repo.init();
  return { location, repo, service: createWorkspaceService(repo, seed) };
}
test('Inicializa los 52 trabajos, las 7 pruebas y los 4 entregables de la guía', async (t) => {
  const { location, service } = await setup();t.after(() => fs.rm(location, { recursive: true, force: true }));
  assert.equal(service.state().tasks.length, 52);
  assert.equal(service.state().tests.length, 7);
  assert.equal(service.state().deliverables.length, 4);
});
test('Crea, edita, cambia estado y elimina una tarea, persiste en JSON', async (t) => {
  const { location, service, repo } = await setup();t.after(() => fs.rm(location, { recursive: true, force: true }));
  const created = await service.createTask({ title:'Revisar API', phase:'chat', priority:'alta' });
  assert.ok(created.id.startsWith('USR-'));
  await service.updateTask(created.id, { status:'doing', notes:'Pendiente de prueba' });
  assert.equal(repo.read().tasks.find(x=>x.id===created.id).status, 'doing');
  await service.deleteTask(created.id);
  assert.equal(repo.read().tasks.some(x=>x.id===created.id), false);
});
test('Rechaza datos inválidos y permite importar JSON de la versión anterior', async (t) => {
  const { location, service } = await setup();t.after(() => fs.rm(location, { recursive: true, force: true }));
  await assert.rejects(service.createTask({title:'A', phase:'inventada'}));
  const old = { ...service.state(), version: 1 };
  old.tasks[0].status = 'done';
  await service.importBackup(old);
  assert.equal(service.state().tasks[0].status, 'done');
});
test('Las operaciones concurrentes no pierden actualizaciones', async (t) => {
  const { location, service } = await setup();t.after(() => fs.rm(location, { recursive: true, force: true }));
  await Promise.all([service.updateTask('PRE-01',{status:'done'}),service.updateTask('PRE-02',{status:'doing'}),service.updateTest(1,{passed:true})]);
  assert.equal(service.state().tasks.find(x=>x.id==='PRE-01').status, 'done');
  assert.equal(service.state().tasks.find(x=>x.id==='PRE-02').status, 'doing');
  assert.equal(service.state().tests[0].passed, true);
});
test('La información permanece después de volver a cargar el repositorio', async (t) => {
  const { location, service } = await setup();t.after(() => fs.rm(location, {recursive:true,force:true}));
  await service.updateTask('PRE-03', {status:'done', owner:'Equipo PolicyBot'});
  const seed = JSON.parse(await fs.readFile(path.resolve(dir, '../src/data/seed.json'), 'utf8'));
  const reopened = jsonRepository(path.join(location, 'board.json'), seed);
  await reopened.init();
  assert.equal(reopened.read().tasks.find(t=>t.id==='PRE-03').owner, 'Equipo PolicyBot');
});
