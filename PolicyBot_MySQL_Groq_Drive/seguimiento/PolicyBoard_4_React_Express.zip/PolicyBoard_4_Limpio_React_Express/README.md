# PolicyBoard 4.0 | React + Node.js / Express

Gestor de tareas para completar la práctica **«SaaS de asistentes con RAG sobre Google Drive»**. Esta versión **sí** tiene frontend React y backend independiente: los avances se envían por HTTP y se guardan en disco por el servidor.

> **Alcance:** PolicyBoard es el gestor de tareas del proyecto académico, **no** la implementación del SaaS PolicyBot con Claude y pgvector. El objetivo es organizar su desarrollo.

## Requisitos

- Node.js **20.19 o superior** (recomendado Node.js 22 LTS).
- npm e Internet para `npm install` en el primer arranque.
- No necesitas Docker ni configurar las API keys de Anthropic para utilizar **este gestor**.

## Arranque rápido

### Windows

1. Descomprime el ZIP.
2. Ejecuta `INICIAR_WINDOWS.bat` (la primera vez instalará las dependencias).
3. Abre **http://127.0.0.1:5173**. Si el iniciador puede, abrirá el navegador automáticamente.

### Linux / macOS

```bash
chmod +x INICIAR_LINUX.sh
./INICIAR_LINUX.sh
```

### Manual, en cualquier sistema

```bash
npm install
npm run dev
```

Con este comando se levantan los dos servicios simultáneamente:

| Servicio | Dirección | Función |
| --- | --- | --- |
| React + Vite | http://127.0.0.1:5173 | Interfaz web |
| Node + Express | http://127.0.0.1:4000/api/health | API REST |

El servidor Vite redirige `/api` al backend en desarrollo.

**Compilación de producción:** `npm run build && npm start` y visita `http://127.0.0.1:4000`. En este modo Express sirve la carpeta `frontend/dist`.

**Pruebas automatizadas:** `npm test`.

## Estructura de carpetas

```text
PolicyBoard_4_Limpio_React_Express/
├── frontend/                       # Aplicación React + Vite
│   ├── public/                     # PDF de la guía y favicon
│   ├── src/
│   │   ├── app/                    # Composición, navegación y layout
│   │   │   └── App.jsx
│   │   ├── components/             # Componentes React reutilizables
│   │   ├── features/
│   │   │   ├── dashboard/          # Vista de inicio y avance
│   │   │   ├── tasks/              # Lista, Kanban y editor
│   │   │   ├── phases/             # Hoja de ruta
│   │   │   ├── quality/            # Pruebas y entregables
│   │   │   └── backups/            # Importar, exportar y restablecer
│   │   ├── hooks/                  # Hook de estado y sincronización API
│   │   ├── services/               # Cliente HTTP centralizado
│   │   ├── styles/                 # CSS global y responsive
│   │   └── main.jsx               # Entrada React
│   ├── index.html
│   ├── vite.config.js
│   └── package.json
├── backend/                        # API Node.js + Express
│   ├── src/
│   │   ├── config/                 # Puerto y rutas de archivos
│   │   ├── controllers/            # Entrada y salida HTTP
│   │   ├── routes/                 # Endpoints /api/*
│   │   ├── services/               # Casos de uso del gestor
│   │   ├── validators/             # Validación de tareas
│   │   ├── repositories/           # Persistencia JSON atómica
│   │   ├── middlewares/            # Errores y rutas inexistentes
│   │   ├── data/seed.json          # 52 tareas + 7 pruebas + 4 entregables
│   │   ├── app.js                  # Configuración de Express
│   │   └── server.js               # Arranque HTTP
│   ├── storage/                    # Archivos de progreso, ignorados por Git
│   ├── tests/                      # Pruebas con node:test
│   ├── .env.example
│   └── package.json
├── docs/                           # Arquitectura y API
├── INICIAR_WINDOWS.bat
├── INICIAR_LINUX.sh
├── package.json                    # Monorepo npm workspaces
└── README.md
```

## ¿Qué incluye?

- **Dashboard «Hoy»** simplificado, cinco próximas tareas, progreso y fase actual sin tarjetas redundantes.
- **Mis tareas**: búsqueda en lista, filtros desplegables, actualización de estado con un clic, responsable, fecha, notas y subtareas.
- **Tablero Kanban** con arrastrar y soltar.
- **Fases** con las ocho etapas del PDF.
- **Pruebas** con las siete validaciones obligatorias.
- **Entregables** con los cuatro archivos/evidencias solicitados.
- **Respaldos JSON y CSV**, restauración inicial e importación de JSON de las versiones 1 y 2.
- Atajos: `N` para nueva tarea y `Ctrl+K` para buscar. La búsqueda ahora muestra cuatro sugerencias al abrirse, hasta seis coincidencias cuando escribes, permite usar flechas/Enter y tiene un acceso para ver todas las tareas.
- **Navegación compacta:** cuatro secciones principales y «Más opciones» para pruebas, entregables y respaldos. La guía PDF y el progreso permanecen accesibles en el pie del menú.

## Cambios visuales de la versión 4

- Se eliminó la ficha de proyecto duplicada y varios indicadores repetidos del menú lateral.
- Las opciones secundarias del menú se ocultan hasta que abras «Más opciones».
- La búsqueda global tiene un panel más pequeño y muestra menos tareas de forma predeterminada.
- La pantalla de inicio reemplaza el banner enorme, las cuatro tarjetas de métricas y la sección de progreso por fase por un resumen breve con la acción prioritaria.
- Los filtros avanzados en «Mis tareas» se muestran solo al solicitarlos.
- Se redujeron bordes y sombras, y se adaptó el diseño a pantallas pequeñas.
- La lógica del backend, el formato de los datos y los endpoints permanecen sin cambios.

### Conservar los datos de PolicyBoard 3.0

Si la versión anterior ya contiene avances, con ambas aplicaciones **detenidas** copia el archivo `backend/storage/policyboard.json` desde el proyecto anterior a la misma ruta del nuevo proyecto. Alternativamente, exporta un respaldo JSON desde la versión anterior e impórtalo desde «Más opciones → Respaldos» en esta versión. No sobrescribas tus datos actuales sin un respaldo previo.

## ¿Dónde se guardan los datos?

En `backend/storage/policyboard.json`, generado automáticamente en el primer arranque. El archivo se excluye con `.gitignore`. Haz respaldos frecuentes en la pestaña **Respaldos**, especialmente antes de cambiar de versión o borrar carpetas.

La primera vez que abres el sistema, las tareas ya están sembradas desde `backend/src/data/seed.json`.

### Migrar desde PolicyBoard 2.0

1. En PolicyBoard antiguo, abre **Respaldos → Exportar JSON**.
2. Inicia este proyecto y visita **Respaldos → Importar**.
3. Selecciona el JSON. Se conservan los estados, notas, subtareas y tareas personalizadas válidas. **La importación reemplaza los datos actuales**, así que exporta el nuevo estado antes si fuera necesario.

No se importan automáticamente los datos de `localStorage` desde `file://` hacia `http://127.0.0.1`; el respaldo JSON es la ruta segura de migración.

## Separación de responsabilidades

- React **nunca** modifica `backend/storage` directamente; usa `frontend/src/services/api.js`.
- Express valida peticiones y aplica la lógica de negocio en `backend/src/services`.
- `backend/src/repositories` centraliza la persistencia, para poder cambiar a PostgreSQL cuando el MVP lo necesite.
- Los datos semilla proceden del gestor anterior basado en la guía original.
- El estado del navegador se actualiza después de confirmar cada operación del servidor.

## Limitaciones del MVP

- Está pensado para **uso local y una sola persona**. **No tiene login ni aislamiento multiusuario**; no es adecuado para publicar en Internet sin agregar autenticación, control de permisos, base de datos y protección adicionales.
- Usa archivo JSON en vez de PostgreSQL. Para edición simultánea de múltiples usuarios se necesitaría una base de datos real.
- No sincroniza con Google Drive, Claude o Voyage: esos son componentes pendientes del **PolicyBot académico** que este tablero te ayuda a implementar.
- No envíes `backend/storage/policyboard.json` a un repositorio público si almacenas información privada en las notas.

Consulta `docs/ARQUITECTURA.md` y `docs/API.md` para detalles.
