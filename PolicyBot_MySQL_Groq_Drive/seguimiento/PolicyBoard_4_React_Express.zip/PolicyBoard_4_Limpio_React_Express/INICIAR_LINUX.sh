#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v node >/dev/null || ! command -v npm >/dev/null; then
  echo 'Necesitas Node.js 20.19+ y npm.' >&2
  exit 1
fi
if [ ! -d node_modules/concurrently ]; then
  npm install
fi
printf 'Web: http://127.0.0.1:5173\nAPI: http://127.0.0.1:4000/api/health\n'
if command -v xdg-open >/dev/null; then (sleep 4; xdg-open http://127.0.0.1:5173 >/dev/null 2>&1 || true) & fi
npm run dev
