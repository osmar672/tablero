# PolicyBoard 4.0: simplificación de la experiencia

La prioridad de esta revisión es reducir elementos en pantalla, no agregar más complejidad.

| Zona | Antes | Ahora |
|---|---|---|
| Menú lateral | Ficha duplicada de proyecto, siete enlaces visibles, guía grande y estado de guardado repetido | Identidad compacta, cuatro secciones principales, herramientas bajo «Más opciones», guía y progreso discretos |
| Búsqueda global | Nueve sugerencias al abrir, panel ancho con desplazamiento | Cuatro sugerencias, seis resultados máximos, lista pequeña, navegación por teclado y «Ver todas» |
| «Hoy» | Banner grande, cuatro tarjetas de métricas, fase, guía, hitos y tabla de todas las fases | Encabezado sencillo, resumen en una línea, cinco tareas próximas, fase actual y dos indicadores de entrega |
| Mis tareas | Filtros de fase/prioridad visibles siempre y botón de alta duplicado | Filtros desplegables y creación centralizada en la barra superior |
| Estilos | Mucho contraste y espacios elevados | Menos sombras, jerarquía tipográfica clara y filas compactas |

## Archivos del frontend modificados

- `src/app/App.jsx`: navegación, búsqueda global y barra superior.
- `src/features/dashboard/Dashboard.jsx`: diseño «Hoy».
- `src/features/tasks/TasksPage.jsx`: filtros plegables.
- `src/components/TaskRow.jsx`: controles accesibles y modo compacto.
- `src/styles/refinement.css`: nueva capa de estilos y adaptabilidad.
- `src/main.jsx`: importa la nueva capa de estilos.

No se han modificado los datos iniciales ni el backend. Al mover los datos del proyecto anterior, las tareas y sus estados se conservan.
