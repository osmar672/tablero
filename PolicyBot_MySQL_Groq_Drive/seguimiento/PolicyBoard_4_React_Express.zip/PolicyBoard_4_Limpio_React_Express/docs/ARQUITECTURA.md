# Arquitectura del gestor

## Flujo de datos

```text
Usuario
  |
  v
React + Vite (localhost:5173)
  |  useWorkspace -> api.js -> fetch('/api/...')
  v
Proxy Vite / API HTTP Express (localhost:4000)
  |  routes -> controllers -> services -> validators
  v
jsonRepository
  |
  v
backend/storage/policyboard.json
```

En producción, Express también sirve el HTML estático generado por Vite.

## Responsabilidades

- **Frontend:** presentación, navegación, filtros locales, editores y confirmación de acciones.
- **API:** HTTP JSON, errores, validación de payloads, creación de IDs y modificaciones de negocio.
- **Repositorio:** mantiene un estado en memoria, serializa las escrituras para no perder operaciones concurrentes de un mismo proceso y reemplaza el archivo JSON con una operación de renombrado atómica en el mismo directorio.
- **Datos iniciales:** se conserva el conjunto de 52 tareas, 7 pruebas y 4 entregables de PolicyBoard 2.0 con las ocho fases de la guía.

## Decisiones del MVP

1. **Monorepo npm workspaces:** una instalación de dependencias y dos apps independientes.
2. **React sin router adicional:** las siete vistas se muestran dentro de un layout SPA, sin rutas públicas separadas; reduce dependencias innecesarias para un MVP local.
3. **Backend Express 5:** rutas separadas, middleware central de errores y límites de tamaño de cuerpos JSON.
4. **Persistencia JSON:** adecuada para una sola instancia local, no para un SaaS concurrente.
5. **Servidor limitado a 127.0.0.1:** no expone por defecto los datos a la red local.
6. **Importación explícita:** los avances previos se migran exportando JSON desde la versión 2 y cargándolo en la versión React.

## Evolución sugerida

Para convertir el propio gestor en una solución de equipo: PostgreSQL, migraciones, esquema de usuarios/proyectos/tareas, autenticación con cookies httpOnly, permisos por proyecto, historial de cambios y pruebas API/end-to-end.

Esto es independiente de los requerimientos del **SaaS PolicyBot** (Claude, RAG, pgvector y Google Drive) descritos en el PDF.
