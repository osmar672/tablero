# Contrato API REST

Base: `http://127.0.0.1:4000/api`

| Método | Endpoint | Descripción |
| --- | --- | --- |
| GET | `/health` | Comprobar que el backend funciona |
| GET | `/bootstrap` | Obtener fases, tareas, pruebas y entregables |
| POST | `/tasks` | Crear tarea |
| PATCH | `/tasks/:id` | Editar campos o estado de una tarea |
| DELETE | `/tasks/:id` | Eliminar tarea |
| PATCH | `/tests/:id` | Cambiar `passed` y/o `note` |
| PATCH | `/deliverables/:id` | Cambiar `done` |
| GET | `/backup` | Descargar un JSON del espacio de trabajo |
| POST | `/backup/import` | Importar respaldo v1 o v2 del gestor |
| POST | `/reset` | Restablecer el estado inicial (requiere `{"confirm":true}`) |

Ejemplo:

```http
POST /api/tasks
Content-Type: application/json

{
  "title":"Verificar la conexión a Google Drive",
  "phase":"documentos",
  "priority":"alta",
  "status":"todo",
  "checklist":[{"text":"Crear cuenta de servicio","done":false}]
}
```

```http
PATCH /api/tasks/PRE-01
Content-Type: application/json

{"status":"done"}
```

Errores usan `{ "error": "mensaje" }` con estados HTTP 400, 404, 413 o 500 según corresponda.

> Por diseño no hay autenticación. Utilízalo solo en localhost.
