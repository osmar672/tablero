@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>&1
if errorlevel 1 (
  echo ERROR: Instala Node.js 20.19 o superior y vuelve a intentarlo.
  echo https://nodejs.org/
  pause
  exit /b 1
)
where npm >nul 2>&1
if errorlevel 1 (
  echo ERROR: No se encontro npm en PATH.
  pause
  exit /b 1
)
if not exist "node_modules\concurrently\package.json" (
  echo Instalando dependencias de frontend y backend...
  call npm install
  if errorlevel 1 (
    echo ERROR: No fue posible instalar dependencias. Revisa Internet y npm.
    pause
    exit /b 1
  )
)
echo.
echo PolicyBoard React + Express
 echo Web: http://127.0.0.1:5173
 echo API: http://127.0.0.1:4000/api/health
 echo Presiona Ctrl+C para detener.
start "" cmd /c "timeout /t 4 /nobreak >nul & start http://127.0.0.1:5173"
call npm run dev
if errorlevel 1 pause
