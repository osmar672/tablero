import { useRef, useState } from 'react';
import { AlertTriangle, DatabaseBackup, Download, FileJson2, RotateCcw, Upload } from 'lucide-react';

function csvCell(value) { return `"${String(value ?? '').replaceAll('"', '""')}"`; }
function downloadCsv(data) {
  const rows = [['ID','Fase','Título','Estado','Prioridad','Responsable','Vencimiento','Notas'], ...data.tasks.map(t=>[t.id,t.phase,t.title,t.status,t.priority,t.owner,t.due,t.notes])];
  const blob = new Blob(['\ufeff' + rows.map(r=>r.map(csvCell).join(';')).join('\r\n')], {type:'text/csv;charset=utf-8'});
  const url=URL.createObjectURL(blob); const link=document.createElement('a');link.href=url;link.download='PolicyBoard_tareas.csv';link.click();setTimeout(()=>URL.revokeObjectURL(url),500);
}
export default function BackupsPage({data,onImport,onReset}) {
  const fileInput=useRef(null);
  const [working,setWorking]=useState(false);
  const [error,setError]=useState('');
  async function importFile(event) {
    const file=event.target.files?.[0]; if(!file)return;
    if(!window.confirm('¿Importar este respaldo? Reemplazará las tareas y avances actuales.')){event.target.value='';return;}
    setWorking(true);setError('');
    try { await onImport(JSON.parse(await file.text())); }
    catch(err){setError(err instanceof SyntaxError?'El archivo no contiene JSON válido.':err.message);}
    finally {setWorking(false);event.target.value='';}
  }
  async function reset() {
    if(window.confirm('¿Restablecer todas las tareas, pruebas y entregables a su estado inicial? Exporta un respaldo antes.')){
      setWorking(true);try{await onReset();}catch(err){setError(err.message);}finally{setWorking(false);}
    }
  }
  return <div className="page-space"><header className="page-heading"><div><span className="eyebrow">ADMINISTRACIÓN</span><h1>Respaldos</h1><p>Importa tus avances de PolicyBoard anterior o exporta una copia del proyecto.</p></div></header>
    <div className="backup-grid"><section className="card backup-card"><div className="backup-icon"><Download size={24}/></div><h2>Exportar progreso</h2><p>Descarga el estado actual de las {data.tasks.length} tareas, pruebas y entregables.</p><a href="/api/backup" download="policyboard-backup.json" className="btn primary"><FileJson2 size={17}/> Descargar JSON</a><button className="btn secondary" onClick={()=>downloadCsv(data)}><Download size={17}/> Descargar tareas CSV</button></section>
      <section className="card backup-card"><div className="backup-icon"><Upload size={24}/></div><h2>Importar respaldo</h2><p>Acepta archivos JSON creados con PolicyBoard 1, 2 o esta versión con React.</p><input ref={fileInput} type="file" accept=".json,application/json" className="sr-only" onChange={importFile}/><button className="btn primary" disabled={working} onClick={()=>fileInput.current?.click()}><Upload size={17}/>{working?'Procesando...':'Elegir archivo JSON'}</button><small>Se sustituirán los datos actuales por los del archivo.</small></section>
    </div>
    <div className="info-box"><DatabaseBackup size={22}/><div><strong>Ahora los datos se guardan en el backend.</strong><p>En lugar de depender de localStorage, PolicyBoard almacena tus cambios en <code>backend/storage/policyboard.json</code>. El frontend se conecta por API.</p></div></div>
    <div className="danger-zone"><div><AlertTriangle size={19}/><span><strong>Restablecer práctica</strong><small>Elimina avances y recupera las 52 tareas iniciales.</small></span></div><button className="btn danger" disabled={working} onClick={reset}><RotateCcw size={16}/> Restablecer</button></div>
    {error && <p className="form-error" role="alert">{error}</p>}
  </div>;
}
