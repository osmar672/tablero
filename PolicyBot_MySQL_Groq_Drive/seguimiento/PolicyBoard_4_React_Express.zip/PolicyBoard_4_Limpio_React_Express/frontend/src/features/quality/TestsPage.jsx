import { Check, FlaskConical } from 'lucide-react';
export default function TestsPage({data,onUpdate}) {
  const finished=data.tests.filter(t=>t.passed).length;
  return <div className="page-space"><header className="page-heading"><div><span className="eyebrow">CONTROL DE CALIDAD</span><h1>Pruebas de aceptación</h1><p>Las siete comprobaciones obligatorias de la práctica, con notas y evidencias.</p></div><span className="page-counter">{finished} de 7 aprobadas</span></header>
    <div className="quality-intro"><FlaskConical size={21}/><div><strong>Una prueba aprobada necesita evidencia.</strong><p>Márcala solo después de ejecutarla en PolicyBot. Escribe el resultado en las notas.</p></div></div>
    <div className="quality-grid">{data.tests.map(test=><article className={`card quality-card ${test.passed?'approved':''}`} key={test.id}>
      <div className="quality-top"><span className="case-number">CASO {String(test.id).padStart(2,'0')}</span><span className={`case-state ${test.passed?'is-passed':''}`}>{test.passed?'Aprobada':'Pendiente'}</span></div>
      <h2>{test.title}</h2><p>{test.question}</p><div className="expected"><strong>Resultado esperado</strong><span>{test.expected}</span></div>
      <label className="field"><span>Notas y evidencias</span><textarea rows="2" defaultValue={test.note} key={test.id+'-'+test.note} onBlur={e=>{if(e.target.value!==test.note)onUpdate(test.id,{note:e.target.value});}} placeholder="Qué ocurrió, evidencia o enlace..."/></label>
      <button className={`check-test ${test.passed?'active':''}`} onClick={()=>onUpdate(test.id,{passed:!test.passed})}><span>{test.passed&&<Check size={17}/>}</span>{test.passed?'Prueba aprobada · desmarcar':'Marcar como aprobada'}</button>
    </article>)}</div>
  </div>;
}
