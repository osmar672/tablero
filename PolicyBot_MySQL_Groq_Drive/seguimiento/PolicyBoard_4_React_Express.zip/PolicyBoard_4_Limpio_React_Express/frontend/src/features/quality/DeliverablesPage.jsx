import { Check, ClipboardCheck, Code2, Database, FileText, Film } from 'lucide-react';
const icons = {repo:Code2,sql:Database,demo:Film,informe:FileText};
export default function DeliverablesPage({data,onUpdate}) {
  const finished=data.deliverables.filter(x=>x.done).length;
  return <div className="page-space"><header className="page-heading"><div><span className="eyebrow">ENTREGA FINAL</span><h1>Entregables</h1><p>Todo lo que debes presentar para que el proyecto quede completo.</p></div><span className="page-counter">{finished} de 4 listos</span></header>
    <div className="deliverable-grid">{data.deliverables.map(item=>{const Icon=icons[item.id]||ClipboardCheck;return <article className={`card deliverable-card ${item.done?'done':''}`} key={item.id}>
      <div className="deliverable-icon"><Icon size={24}/></div><h2>{item.name}</h2><span className="deliverable-subtitle">{item.subtitle}</span><p>{item.description}</p><div className="deliverable-detail">{item.detail}</div>
      <button className={`deliverable-button ${item.done?'active':''}`} onClick={()=>onUpdate(item.id,{done:!item.done})}><span>{item.done?<Check size={17}/>:null}</span>{item.done?'Entregable terminado':'Marcar como listo'}</button>
    </article>;})}</div>
  </div>;
}
