import { ArrowRight, CheckCircle2, ClipboardCheck, Layers, ListTodo, PackageCheck } from 'lucide-react';
import ProgressBar from '../../components/ProgressBar.jsx';
import TaskRow from '../../components/TaskRow.jsx';
import EmptyState from '../../components/EmptyState.jsx';
import { pct, sortTasks } from '../tasks/taskUtils.js';

export default function Dashboard({ data, onNavigate, onEdit, onStatus }) {
  const total = data.tasks.length;
  const done = data.tasks.filter(task => task.status === 'done').length;
  const doing = data.tasks.filter(task => task.status === 'doing').length;
  const blocked = data.tasks.filter(task => task.status === 'blocked').length;
  const passed = data.tests.filter(test => test.passed).length;
  const delivered = data.deliverables.filter(item => item.done).length;
  const focus = sortTasks(data.tasks.filter(task => ['todo', 'doing'].includes(task.status)), data.phases).slice(0, 5);
  const activePhase = data.phases.find(phase => data.tasks.some(task => task.phase === phase.id && task.status !== 'done')) || data.phases.at(-1);
  const phaseTasks = data.tasks.filter(task => task.phase === activePhase?.id);
  const phaseDone = phaseTasks.filter(task => task.status === 'done').length;

  return (
    <div className="page-space home-page home-v4">
      <header className="welcome-v4">
        <div>
          <span className="eyebrow">TU ESPACIO DE TRABAJO</span>
          <h1>En qué trabajar hoy</h1>
          <p>Empieza por una tarea y avanza a tu ritmo.</p>
        </div>
        <div className="welcome-progress">
          <div className="welcome-progress-top"><span>Progreso general</span><strong>{pct(done, total)}%</strong></div>
          <ProgressBar value={pct(done, total)} />
          <small>{done} de {total} tareas completadas</small>
        </div>
      </header>
      <div className="activity-line" role="group" aria-label="Resumen de tareas">
        <span><i className="activity-dot dot-todo" />{data.tasks.filter(task => task.status === 'todo').length} pendientes</span>
        <span><i className="activity-dot dot-doing" />{doing} en curso</span>
        <span><i className="activity-dot dot-blocked" />{blocked} bloqueadas</span>
      </div>
      <div className="dashboard-grid dashboard-grid-v4">
        <section className="card focus-v4">
          <div className="card-header focus-heading">
            <div><h2>Tu siguiente paso</h2><p>Las tareas más importantes para continuar.</p></div>
            <span className="focus-count">{focus.length} visibles</span>
          </div>
          <div className="row-list">
            {focus.length
              ? focus.map(task => <TaskRow key={task.id} task={task} phases={data.phases} onEdit={onEdit} onStatus={onStatus} compact />)
              : <EmptyState title="Todas las tareas terminadas" description="Revisa las pruebas y los entregables." />}
          </div>
          <button type="button" className="focus-view-all" onClick={() => onNavigate('tasks')}>
            <ListTodo size={17} /> Ver todas las tareas <ArrowRight size={16} />
          </button>
        </section>
        <div className="dashboard-aside dashboard-aside-v4">
          <section className="card current-phase-v4">
            <div className="mini-card-title"><Layers size={17} /><span>Fase actual</span></div>
            <h2>{activePhase?.name || 'Sin fase activa'}</h2>
            <div className="phase-progress-v4"><span>{phaseDone} de {phaseTasks.length} tareas</span><strong>{pct(phaseDone, phaseTasks.length)}%</strong></div>
            <ProgressBar value={pct(phaseDone, phaseTasks.length)} />
            <button className="quiet-link" type="button" onClick={() => onNavigate('phases')}>Ir a fases <ArrowRight size={16} /></button>
          </section>
          <section className="card checklists-v4">
            <div className="mini-card-title"><CheckCircle2 size={17} /><span>Antes de entregar</span></div>
            <button type="button" onClick={() => onNavigate('tests')}>
              <ClipboardCheck size={18} /><span>Pruebas</span><strong>{passed}/{data.tests.length}</strong><ChevronForward />
            </button>
            <button type="button" onClick={() => onNavigate('deliverables')}>
              <PackageCheck size={18} /><span>Entregables</span><strong>{delivered}/{data.deliverables.length}</strong><ChevronForward />
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}
function ChevronForward() { return <ArrowRight size={15} aria-hidden="true" />; }
