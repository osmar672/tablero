export const statusOptions = [
  { id: 'todo', label: 'Por hacer' }, { id: 'doing', label: 'En progreso' },
  { id: 'blocked', label: 'Bloqueada' }, { id: 'done', label: 'Completada' },
];
export const priorities = [{ id: 'alta', label: 'Alta' }, { id: 'media', label: 'Media' }, { id: 'baja', label: 'Baja' }];
export const phaseName = (phases, id) => phases.find((p) => p.id === id)?.name || id;
export const pct = (a, b) => b ? Math.round(a / b * 100) : 0;
const pRank = { alta: 0, media: 1, baja: 2 };
export function sortTasks(tasks, phases) {
  const phaseRank = Object.fromEntries(phases.map((p, i) => [p.id, i]));
  const sRank = { doing: 0, todo: 1, blocked: 2, done: 3 };
  return [...tasks].sort((a, b) => (sRank[a.status] - sRank[b.status])
    || ((a.due || '9999').localeCompare(b.due || '9999'))
    || (pRank[a.priority] - pRank[b.priority])
    || (phaseRank[a.phase] - phaseRank[b.phase]));
}
