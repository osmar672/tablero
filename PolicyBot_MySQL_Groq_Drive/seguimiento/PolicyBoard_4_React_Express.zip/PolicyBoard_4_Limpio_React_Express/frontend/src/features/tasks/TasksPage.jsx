import { useMemo, useState } from 'react';
import { ChevronDown, Search, SlidersHorizontal, X } from 'lucide-react';
import TaskRow from '../../components/TaskRow.jsx';
import EmptyState from '../../components/EmptyState.jsx';
import { sortTasks } from './taskUtils.js';

export default function TasksPage({ data, onEdit, onStatus }) {
  const [query, setQuery] = useState('');
  const [status, setStatus] = useState('active');
  const [phase, setPhase] = useState('all');
  const [priority, setPriority] = useState('all');
  const [filtersOpen, setFiltersOpen] = useState(false);
  const isFiltered = phase !== 'all' || priority !== 'all';
  const filtered = useMemo(() => sortTasks(data.tasks.filter(task => {
    if (status === 'active' && task.status === 'done') return false;
    if (!['all', 'active'].includes(status) && task.status !== status) return false;
    if (phase !== 'all' && task.phase !== phase) return false;
    if (priority !== 'all' && task.priority !== priority) return false;
    return `${task.title} ${task.id} ${task.description} ${task.notes || ''} ${task.owner || ''}`.toLowerCase().includes(query.trim().toLowerCase());
  }), data.phases), [data, status, phase, priority, query]);

  return <div className="page-space tasks-v4">
    <header className="page-heading"><div><h1>Mis tareas</h1><p>Todo lo que necesitas hacer, en un solo lugar.</p></div></header>
    <section className="card tasks-panel">
      <div className="toolbar-top">
        <div className="segmented" aria-label="Filtrar tareas por estado">{[['active', 'Pendientes'], ['all', 'Todas'], ['doing', 'En curso'], ['done', 'Hechas']].map(([id, label]) => <button type="button" key={id} aria-pressed={status === id} className={status === id ? 'selected' : ''} onClick={() => setStatus(id)}>{label}</button>)}</div>
        <div className="search-field"><Search size={17} /><input aria-label="Buscar en lista" placeholder="Buscar en esta lista..." value={query} onChange={event => setQuery(event.target.value)} /></div>
        <button type="button" className={`filter-toggle ${filtersOpen || isFiltered ? 'active' : ''}`} onClick={() => setFiltersOpen(open => !open)} aria-expanded={filtersOpen}><SlidersHorizontal size={17} /><span>Filtros{isFiltered ? ' · Activos' : ''}</span><ChevronDown size={14} /></button>
      </div>
      {filtersOpen && <div className="filter-strip filter-strip-v4">
        <select aria-label="Filtrar por fase" value={phase} onChange={event => setPhase(event.target.value)}><option value="all">Todas las fases</option>{data.phases.map(item => <option key={item.id} value={item.id}>{item.name}</option>)}</select>
        <select aria-label="Filtrar por prioridad" value={priority} onChange={event => setPriority(event.target.value)}><option value="all">Todas las prioridades</option><option value="alta">Alta</option><option value="media">Media</option><option value="baja">Baja</option></select>
        {isFiltered && <button type="button" className="filter-clear" onClick={() => {setPhase('all');setPriority('all');}}><X size={15} /> Limpiar filtros</button>}
      </div>}
      <div className="list-count">{filtered.length} tareas {isFiltered ? 'con los filtros elegidos' : ''}</div>
      <div className="row-list">{filtered.length ? filtered.map(task => <TaskRow key={task.id} task={task} phases={data.phases} onEdit={onEdit} onStatus={onStatus} />) : <EmptyState />}</div>
    </section>
  </div>;
}
