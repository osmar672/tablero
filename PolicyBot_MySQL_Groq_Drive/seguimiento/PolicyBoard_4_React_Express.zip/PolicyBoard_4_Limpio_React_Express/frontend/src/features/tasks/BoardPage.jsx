import { useState } from 'react';
import { ArrowUpRight, GripVertical } from 'lucide-react';
import EmptyState from '../../components/EmptyState.jsx';
import { statusOptions } from './taskUtils.js';

export default function BoardPage({ data, onEdit, onStatus }) {
  const [phase, setPhase] = useState('all');
  const [dragId, setDragId] = useState(null);
  const [over, setOver] = useState(null);
  return <div className="page-space"><header className="page-heading"><div><span className="eyebrow">FLUJO VISUAL</span><h1>Tablero</h1><p>Arrastra las tarjetas entre columnas o cambia su estado desde el editor.</p></div>
    <select className="board-filter" aria-label="Filtrar tablero por fase" value={phase} onChange={e=>setPhase(e.target.value)}><option value="all">Todas las fases</option>{data.phases.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></header>
    <div className="kanban-grid">{statusOptions.map(status => {
      const tasks = data.tasks.filter(t => t.status===status.id && (phase==='all' || t.phase===phase));
      return <section key={status.id} className={`kanban-column ${over===status.id?'drag-over':''}`} onDragOver={e=>{e.preventDefault();setOver(status.id);}} onDragLeave={()=>setOver(null)} onDrop={e=>{e.preventDefault();setOver(null);if(dragId){onStatus(dragId,status.id);setDragId(null);}}}>
        <header className="kanban-head"><span className={`kanban-dot dot-${status.id}`}></span><h2>{status.label}</h2><span className="kanban-count">{tasks.length}</span></header>
        <div className="kanban-stack">{tasks.map(task => <article className="kanban-card" key={task.id} draggable onDragStart={e=>{setDragId(task.id);e.dataTransfer.effectAllowed='move';}} onDragEnd={()=>{setDragId(null);setOver(null);}}>
          <div className="kanban-card-top"><span>{task.id}</span><GripVertical size={16}/></div>
          <button className="kanban-title" onClick={()=>onEdit(task)}>{task.title}</button>
          <p>{data.phases.find(p=>p.id===task.phase)?.short}</p>
          <div className="kanban-foot"><span className={`tag priority-${task.priority}`}>{task.priority}</span><button className="icon-button" onClick={()=>onEdit(task)} aria-label={`Editar ${task.title}`}><ArrowUpRight size={16}/></button></div>
        </article>)}{!tasks.length && <div className="kanban-empty">Suelta tareas aquí</div>}</div>
      </section>;
    })}</div>
  </div>;
}
