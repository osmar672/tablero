import { useEffect, useState } from 'react';
import { Check, Plus, Trash2, X } from 'lucide-react';
import { statusOptions, priorities } from './taskUtils.js';

const blank = { title:'', description:'', phase:'preparacion', priority:'media', status:'todo', owner:'', due:'', notes:'', checklist:[] };
export default function TaskEditor({ task, phases, onSave, onDelete, onClose }) {
  const [form, setForm] = useState(task || blank);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => { const listener = (event) => { if (event.key === 'Escape') onClose(); }; window.addEventListener('keydown', listener);return () => window.removeEventListener('keydown', listener); }, [onClose]);
  function edit(name, value) { setForm((f) => ({ ...f, [name]: value })); }
  async function submit(event) {
    event.preventDefault();
    if (!form.title.trim()) { setError('Escribe un título para la tarea.');return; }
    setSaving(true); setError('');
    try { await onSave(form); onClose(); }
    catch (err) { setError(err.message); }
    finally { setSaving(false); }
  }
  async function remove() {
    if (window.confirm('¿Eliminar esta tarea? Esta acción no se puede deshacer.')) {
      try { await onDelete(form.id); onClose(); } catch (err) { setError(err.message); }
    }
  }
  return <div className="drawer-backdrop" onMouseDown={(e) => {if(e.target === e.currentTarget) onClose();}}>
    <section className="task-drawer" role="dialog" aria-modal="true" aria-label={task ? 'Editar tarea' : 'Nueva tarea'}>
      <div className="drawer-top"><div><span className="eyebrow">{task ? task.id : 'NUEVA TAREA'}</span><h2>{task ? 'Detalle de tarea' : 'Crear tarea'}</h2></div><button className="icon-button" onClick={onClose} aria-label="Cerrar"><X size={21}/></button></div>
      <form onSubmit={submit} className="drawer-form" id="task-edit-form">
        <label className="field"><span>Título <b>*</b></span><input required minLength="2" maxLength="180" autoFocus value={form.title} onChange={e => edit('title', e.target.value)} placeholder="Ej. Configurar endpoint de chat"/></label>
        <label className="field"><span>Descripción</span><textarea rows="3" value={form.description || ''} onChange={e => edit('description', e.target.value)} placeholder="Qué se necesita hacer y cómo validar el resultado"/></label>
        <div className="form-grid"><label className="field"><span>Fase</span><select value={form.phase} onChange={e => edit('phase', e.target.value)}>{phases.map(p => <option key={p.id} value={p.id}>{p.short}: {p.name}</option>)}</select></label>
        <label className="field"><span>Estado</span><select value={form.status} onChange={e => edit('status', e.target.value)}>{statusOptions.map(s => <option key={s.id} value={s.id}>{s.label}</option>)}</select></label>
        <label className="field"><span>Prioridad</span><select value={form.priority} onChange={e => edit('priority', e.target.value)}>{priorities.map(p => <option key={p.id} value={p.id}>{p.label}</option>)}</select></label>
        <label className="field"><span>Fecha límite</span><input type="date" value={form.due || ''} onChange={e => edit('due', e.target.value)}/></label>
        </div>
        <label className="field"><span>Responsable</span><input value={form.owner || ''} onChange={e => edit('owner', e.target.value)} placeholder="Nombre o iniciales"/></label>
        <div className="field"><div className="form-heading"><span>Pasos de la tarea <small>({(form.checklist || []).filter(x=>x.done).length}/{form.checklist?.length || 0})</small></span><button type="button" className="text-action" onClick={() => edit('checklist', [...(form.checklist || []), {text:'', done:false}])}><Plus size={15}/> Agregar paso</button></div>
          {(form.checklist || []).map((step, i) => <div className="step-editor" key={i}>
            <input type="checkbox" aria-label={`Completar paso ${i+1}`} checked={step.done} onChange={e => edit('checklist', form.checklist.map((x,n) => n===i ? {...x, done:e.target.checked} : x))}/>
            <input aria-label={`Descripción del paso ${i+1}`} value={step.text} onChange={e => edit('checklist', form.checklist.map((x,n) => n===i ? {...x, text:e.target.value} : x))} placeholder="Escribe el paso"/>
            <button className="icon-button small-icon" type="button" onClick={() => edit('checklist', form.checklist.filter((_,n) => n!==i))} aria-label="Eliminar paso"><X size={15}/></button>
          </div>)}
        </div>
        <label className="field"><span>Notas y evidencias</span><textarea rows="4" value={form.notes || ''} onChange={e => edit('notes', e.target.value)} placeholder="Enlaces, resultados, bloqueos y detalles útiles..."/></label>
        {task?.page && <a className="guide-inline" target="_blank" rel="noreferrer" href={`/Guia_Practica_PolicyBot.pdf#page=${task.page}`}>Abrir la página {task.page} de la guía ↗</a>}
        {error && <p className="form-error" role="alert">{error}</p>}
      </form>
      <div className="drawer-footer">{task && <button className="btn danger" type="button" onClick={remove}><Trash2 size={16}/> Eliminar</button>}
        <div className="footer-right"><button className="btn secondary" onClick={onClose}>Cancelar</button><button type="submit" form="task-edit-form" className="btn primary" disabled={saving}><Check size={17}/>{saving ? 'Guardando...' : 'Guardar tarea'}</button></div>
      </div>
    </section>
  </div>;
}
