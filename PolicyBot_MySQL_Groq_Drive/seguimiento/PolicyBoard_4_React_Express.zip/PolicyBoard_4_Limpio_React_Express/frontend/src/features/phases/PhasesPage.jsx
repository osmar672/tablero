import { BookOpen, Check, ChevronRight } from 'lucide-react';
import ProgressBar from '../../components/ProgressBar.jsx';
import TaskRow from '../../components/TaskRow.jsx';
import { pct, sortTasks } from '../tasks/taskUtils.js';
import { useState } from 'react';

export default function PhasesPage({data,onEdit,onStatus}) {
  const [selected,setSelected] = useState('preparacion');
  const phase = data.phases.find(x=>x.id===selected) || data.phases[0];
  const tasks = sortTasks(data.tasks.filter(t=>t.phase===phase.id),data.phases);
  return <div className="page-space"><header className="page-heading"><div><span className="eyebrow">HOJA DE RUTA</span><h1>Fases de la práctica</h1><p>Ocho etapas, ordenadas según la guía de laboratorio.</p></div></header>
    <div className="phases-layout"><div className="phase-menu">{data.phases.map((p,index)=>{
      const ts=data.tasks.filter(t=>t.phase===p.id); const done=ts.filter(t=>t.status==='done').length;
      return <button className={`phase-menu-item ${selected===p.id?'active':''}`} key={p.id} onClick={()=>setSelected(p.id)}><span className="phase-menu-index">{String(index+1).padStart(2,'0')}</span><span><strong>{p.name}</strong><small>{done}/{ts.length} tareas · Sesión {p.session}</small></span>{done===ts.length?<Check size={18}/>:<ChevronRight size={17}/>}</button>;
    })}</div>
    <section className="card phase-detail"><div className="phase-detail-head"><div><span className="eyebrow">{phase.short} · SESIÓN {phase.session}</span><h2>{phase.name}</h2><p>{phase.detail}</p></div><a className="btn secondary" href={`/Guia_Practica_PolicyBot.pdf#page=${phase.page}`} target="_blank" rel="noreferrer"><BookOpen size={17}/> Ver guía</a></div>
      <div className="phase-detail-progress"><ProgressBar value={pct(tasks.filter(t=>t.status==='done').length,tasks.length)}/><span>{tasks.filter(t=>t.status==='done').length}/{tasks.length} completadas</span></div>
      <div className="row-list">{tasks.map(t=><TaskRow key={t.id} task={t} phases={data.phases} onEdit={onEdit} onStatus={onStatus} compact/>)}</div>
    </section></div>
  </div>;
}
