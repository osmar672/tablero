import { useCallback, useEffect, useRef, useState } from 'react';
import { api } from '../services/api.js';

export function useWorkspace() {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');
  const timeout = useRef(null);
  const notify = useCallback((message) => {
    setNotice(message);
    window.clearTimeout(timeout.current);
    timeout.current = window.setTimeout(() => setNotice(''), 3000);
  }, []);
  const refresh = useCallback(async () => {
    try { setData(await api.bootstrap()); setError(''); }
    catch (err) { setError(err.message); }
  }, []);
  useEffect(() => {
    refresh();
    return () => window.clearTimeout(timeout.current);
  }, [refresh]);
  const handle = useCallback(async (requestFn, updateFn, message) => {
    try {
      const result = await requestFn();
      if (updateFn) setData((current) => current ? updateFn(current, result) : current);
      if (message) notify(message);
      return result;
    } catch (err) { notify(`Error: ${err.message}`); throw err; }
  }, [notify]);
  const saveTask = async (input) => input.id
    ? handle(() => api.updateTask(input.id, input), (s, item) => ({ ...s, tasks: s.tasks.map((t) => t.id === item.id ? item : t) }), 'Tarea guardada')
    : handle(() => api.createTask(input), (s, item) => ({ ...s, tasks: [item, ...s.tasks] }), 'Tarea creada');
  const changeStatus = (id, status) => handle(() => api.updateTask(id, { status }),
    (s, item) => ({ ...s, tasks: s.tasks.map((t) => t.id === item.id ? item : t) }), 'Estado actualizado');
  const removeTask = (id) => handle(() => api.removeTask(id),
    (s) => ({ ...s, tasks: s.tasks.filter((t) => t.id !== id) }), 'Tarea eliminada');
  const updateTest = (id, data) => handle(() => api.updateTest(id, data),
    (s, item) => ({ ...s, tests: s.tests.map((t) => t.id === item.id ? item : t) }), 'Prueba actualizada');
  const updateDeliverable = (id, data) => handle(() => api.updateDeliverable(id, data),
    (s, item) => ({ ...s, deliverables: s.deliverables.map((t) => t.id === item.id ? item : t) }), 'Entregable actualizado');
  const importBackup = async (backup) => { await handle(() => api.importBackup(backup), null, 'Respaldo importado'); await refresh(); };
  const reset = async () => { await handle(() => api.reset(), null, 'Proyecto restablecido'); await refresh(); };
  return { data, error, notice, refresh, notify, saveTask, changeStatus, removeTask,
    updateTest, updateDeliverable, importBackup, reset };
}
