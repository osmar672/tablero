import { useCallback, useEffect, useMemo, useState } from 'react';
import {
  ArrowRight, BookOpen, Check, ChevronDown, ChevronRight, ClipboardCheck,
  Columns3, Command, Download, LayoutDashboard, Layers, ListTodo,
  Menu, MoreHorizontal, Plus, Search, X,
} from 'lucide-react';
import { useWorkspace } from '../hooks/useWorkspace.js';
import Dashboard from '../features/dashboard/Dashboard.jsx';
import TasksPage from '../features/tasks/TasksPage.jsx';
import BoardPage from '../features/tasks/BoardPage.jsx';
import TaskEditor from '../features/tasks/TaskEditor.jsx';
import PhasesPage from '../features/phases/PhasesPage.jsx';
import TestsPage from '../features/quality/TestsPage.jsx';
import DeliverablesPage from '../features/quality/DeliverablesPage.jsx';
import BackupsPage from '../features/backups/BackupsPage.jsx';
import ProgressBar from '../components/ProgressBar.jsx';
import { pct, sortTasks } from '../features/tasks/taskUtils.js';

const MAIN_NAV = [
  { id: 'home', title: 'Hoy', Icon: LayoutDashboard },
  { id: 'tasks', title: 'Mis tareas', Icon: ListTodo },
  { id: 'board', title: 'Tablero', Icon: Columns3 },
  { id: 'phases', title: 'Fases', Icon: Layers },
];
const EXTRA_NAV = [
  { id: 'tests', title: 'Pruebas', Icon: ClipboardCheck },
  { id: 'deliverables', title: 'Entregables', Icon: Download },
  { id: 'backups', title: 'Respaldos', Icon: Command },
];
const TITLES = {
  home: 'Hoy', tasks: 'Mis tareas', board: 'Tablero', phases: 'Fases',
  tests: 'Pruebas', deliverables: 'Entregables', backups: 'Respaldos',
};


function NavButton({ item, currentPage, onNavigate, passed }) {
  const { id, title, Icon } = item;
  return <button
    type="button"
    className={`nav-item ${currentPage === id ? 'selected' : ''}`}
    onClick={() => onNavigate(id)}
    aria-current={currentPage === id ? 'page' : undefined}
  >
    <Icon size={19} strokeWidth={1.85} aria-hidden="true" />
    <span>{title}</span>
    {id === 'tests' && <small>{passed}/7</small>}
  </button>;
}

function SearchPalette({ data, onClose, onSelect, onViewAll }) {
  const [term, setTerm] = useState('');
  const [activeIndex, setActiveIndex] = useState(0);
  const found = useMemo(() => {
    const query = term.trim().toLocaleLowerCase();
    const matches = data.tasks.filter(task =>
      query
        ? `${task.title} ${task.id} ${task.description ?? ''} ${task.notes ?? ''}`.toLocaleLowerCase().includes(query)
        : task.status !== 'done',
    );
    return sortTasks(matches, data.phases).slice(0, query ? 6 : 4);
  }, [data, term]);

  useEffect(() => setActiveIndex(0), [term]);
  useEffect(() => {
    function handleKey(event) {
      if (event.key === 'Escape') { event.preventDefault(); onClose(); }
      if (event.key === 'ArrowDown') {
        event.preventDefault(); setActiveIndex(index => Math.max(0, Math.min(index + 1, found.length - 1)));
      }
      if (event.key === 'ArrowUp') {
        event.preventDefault(); setActiveIndex(index => Math.max(index - 1, 0));
      }
      if (event.key === 'Enter' && found[activeIndex]) {
        event.preventDefault(); onSelect(found[activeIndex]);
      }
    }
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [activeIndex, found, onClose, onSelect]);

  return (
    <div className="palette-shade" onMouseDown={event => event.target === event.currentTarget && onClose()}>
      <section className="palette palette-v4" role="dialog" aria-modal="true" aria-label="Buscar tareas">
        <div className="palette-search">
          <Search size={19} aria-hidden="true" />
          <input
            autoFocus
            aria-label="Buscar tareas"
            placeholder="Buscar tarea, código o palabra clave..."
            value={term}
            onChange={event => setTerm(event.target.value)}
          />
          <button type="button" className="palette-close" aria-label="Cerrar búsqueda" onClick={onClose}>
            <X size={18} />
          </button>
        </div>
        <div className="palette-body">
          <div className="palette-caption">
            <span>{term.trim() ? 'Resultados' : 'Para empezar'}</span>
            <small>{term.trim() ? `${found.length} coincidencias visibles` : 'Tareas sugeridas'}</small>
          </div>
          <div className="palette-results" role="listbox" aria-label="Tareas encontradas">
            {found.length ? found.map((task, index) => (
              <button
                type="button"
                role="option"
                aria-selected={activeIndex === index}
                key={task.id}
                className={`palette-result ${activeIndex === index ? 'is-active' : ''}`}
                onMouseEnter={() => setActiveIndex(index)}
                onClick={() => onSelect(task)}
              >
                <span className={`palette-status ${task.status === 'doing' ? 'working' : ''} ${task.status === 'done' ? 'finished' : ''}`} aria-hidden="true" />
                <span className="palette-result-text"><strong>{task.title}</strong><small>{data.phases.find(phase => phase.id === task.phase)?.name || 'Sin fase'}</small></span>
                <span className="palette-code">{task.id}</span>
                <ArrowRight size={15} aria-hidden="true" />
              </button>
            )) : <p className="palette-no-results">No hay resultados. Prueba con otra palabra.</p>}
          </div>
          <button type="button" className="palette-all" onClick={onViewAll}>Ver todas las tareas <ArrowRight size={15} /></button>
        </div>
        <div className="palette-footer"><span><kbd>↑</kbd><kbd>↓</kbd> navegar</span><span><kbd>↵</kbd> abrir</span><span><kbd>Esc</kbd> cerrar</span></div>
      </section>
    </div>
  );
}

export default function App() {
  const ws = useWorkspace();
  const [page, setPage] = useState('home');
  const [selectedTask, setSelectedTask] = useState(null);
  const [editorOpen, setEditorOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [extraOpen, setExtraOpen] = useState(false);

  const navigate = useCallback(id => {
    setPage(id);
    setMobileOpen(false);
    if (EXTRA_NAV.some(item => item.id === id)) setExtraOpen(true);
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, []);
  const edit = useCallback(task => {
    setSelectedTask(task);
    setEditorOpen(true);
    setSearchOpen(false);
  }, []);
  const create = useCallback(() => { setSelectedTask(null); setEditorOpen(true); }, []);
  const closeEditor = useCallback(() => setEditorOpen(false), []);
  const closeSearch = useCallback(() => setSearchOpen(false), []);
  const viewAll = useCallback(() => { closeSearch(); navigate('tasks'); }, [closeSearch, navigate]);

  useEffect(() => {
    function handleKeys(event) {
      const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName) || document.activeElement?.isContentEditable;
      if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'k') {
        event.preventDefault();
        if (!editorOpen) setSearchOpen(open => !open);
        return;
      }
      if (typing || editorOpen || searchOpen || event.ctrlKey || event.altKey || event.metaKey) return;
      if (event.key.toLowerCase() === 'n') { event.preventDefault(); create(); }
    }
    window.addEventListener('keydown', handleKeys);
    return () => window.removeEventListener('keydown', handleKeys);
  }, [editorOpen, searchOpen, create]);

  if (!ws.data) return (
    <div className="loading-screen"><div className="brand-logo">P<span>.</span></div>
      <h1>PolicyBoard</h1><p>{ws.error || 'Cargando espacio de trabajo...'}</p>
      {ws.error && <button className="btn primary" onClick={ws.refresh}>Reintentar conexión</button>}
    </div>
  );
  const data = ws.data;
  const complete = data.tasks.filter(task => task.status === 'done').length;
  const ratio = pct(complete, data.tasks.length);
  const passed = data.tests.filter(test => test.passed).length;
  const onStatus = (id, value) => ws.changeStatus(id, value).catch(() => {});
  const onTest = (id, patch) => ws.updateTest(id, patch).catch(() => {});
  const onDeliverable = (id, patch) => ws.updateDeliverable(id, patch).catch(() => {});

  function renderPage() {
    switch (page) {
      case 'tasks': return <TasksPage data={data} onEdit={edit} onNew={create} onStatus={onStatus} />;
      case 'board': return <BoardPage data={data} onEdit={edit} onStatus={onStatus} />;
      case 'phases': return <PhasesPage data={data} onEdit={edit} onStatus={onStatus} />;
      case 'tests': return <TestsPage data={data} onUpdate={onTest} />;
      case 'deliverables': return <DeliverablesPage data={data} onUpdate={onDeliverable} />;
      case 'backups': return <BackupsPage data={data} onImport={ws.importBackup} onReset={ws.reset} />;
      default: return <Dashboard data={data} onNavigate={navigate} onEdit={edit} onNew={create} onStatus={onStatus} />;
    }
  }

  return (
    <div className="shell shell-v4">
      <aside className={`sidebar sidebar-v4 ${mobileOpen ? 'mobile-visible' : ''}`}>
        <div className="brand sidebar-brand">
          <span className="brand-logo">P<span>.</span></span>
          <div><strong>PolicyBoard</strong><small>PolicyBot MVP</small></div>
          <button type="button" className="icon-button close-mobile" aria-label="Cerrar menú" onClick={() => setMobileOpen(false)}><X size={20} /></button>
        </div>
        <nav className="side-nav" aria-label="Navegación principal">
          {MAIN_NAV.map(item => <NavButton key={item.id} item={item} currentPage={page} onNavigate={navigate} passed={passed} />)}
          <div className="side-divider" />
          <button type="button" className={`nav-item nav-more ${extraOpen ? 'is-expanded' : ''}`} onClick={() => setExtraOpen(value => !value)} aria-expanded={extraOpen} aria-controls="secondary-nav">
            <MoreHorizontal size={19} strokeWidth={1.85} aria-hidden="true" />
            <span>Más opciones</span><ChevronDown size={15} className="nav-chevron" />
          </button>
          {extraOpen && <div id="secondary-nav" className="secondary-nav">{EXTRA_NAV.map(item => <NavButton key={item.id} item={item} currentPage={page} onNavigate={navigate} passed={passed} />)}</div>}
        </nav>
        <div className="sidebar-spacer" />
        <div className="sidebar-footer-v4">
          <section className="side-progress" aria-label="Progreso del proyecto">
            <div><span>Avance del proyecto</span><strong>{ratio}%</strong></div>
            <ProgressBar value={ratio} />
            <small>{complete} de {data.tasks.length} tareas</small>
          </section>
          <div className="sidebar-utility">
            <a href="/Guia_Practica_PolicyBot.pdf" target="_blank" rel="noreferrer"><BookOpen size={16} /> Guía PDF <ChevronRight size={14} /></a>
            <span className="save-status" title="Los cambios se guardan en el servidor"><span className="online-dot" /> Guardado</span>
          </div>
        </div>
      </aside>
      {mobileOpen && <div className="mobile-overlay" onClick={() => setMobileOpen(false)} />}
      <div className="main-layout">
        <header className="topbar">
          <div className="topbar-left">
            <button type="button" className="icon-button hamburger" aria-label="Abrir menú" onClick={() => setMobileOpen(true)}><Menu size={22} /></button>
            <span>PolicyBot</span><ChevronRight size={14} className="slash" /><strong>{TITLES[page]}</strong>
          </div>
          <div className="topbar-tools">
            <button type="button" className="search-trigger" onClick={() => setSearchOpen(true)} aria-label="Buscar tareas (Ctrl K)"><Search size={18} /><span>Buscar</span><kbd>Ctrl K</kbd></button>
            <button type="button" className="btn primary new-task-btn" onClick={create}><Plus size={18} /><span>Nueva tarea</span></button>
          </div>
        </header>
        <main className="main-container">{renderPage()}</main>
      </div>
      {editorOpen && <TaskEditor key={selectedTask?.id || 'new'} task={selectedTask} phases={data.phases} onSave={ws.saveTask} onDelete={ws.removeTask} onClose={closeEditor} />}
      {searchOpen && <SearchPalette data={data} onClose={closeSearch} onSelect={edit} onViewAll={viewAll} />}
      {ws.notice && <div className="toast" role="status"><Check size={16} /> {ws.notice}</div>}
    </div>
  );
}
