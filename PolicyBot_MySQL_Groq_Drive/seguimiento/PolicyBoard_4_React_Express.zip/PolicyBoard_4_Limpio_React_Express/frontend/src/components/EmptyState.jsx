import { Inbox } from 'lucide-react';
export default function EmptyState({ title = 'No hay resultados', description = 'Prueba con otros filtros.' }) {
  return <div className="empty-state"><Inbox size={28}/><strong>{title}</strong><p>{description}</p></div>;
}
