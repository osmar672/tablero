import { ArrowUpRight, Check, Play, RotateCcw } from 'lucide-react';
import { phaseName } from '../features/tasks/taskUtils.js';
export default function TaskRow({ task, phases, onEdit, onStatus, compact = false }) {
  const done = task.status === 'done';
  return <article className={`task-row ${compact ? 'is-compact' : ''} ${done ? 'task-row-done' : ''}`}>
    <button className={`task-checkbox ${done ? 'is-checked' : ''}`} onClick={() => onStatus(task.id, done ? 'todo' : 'done')}
      aria-label={done ? `Reabrir ${task.title}` : `Completar ${task.title}`} title={done ? 'Reabrir' : 'Completar'}>{done && <Check size={16}/>}</button>
    <button className="row-content" onClick={() => onEdit(task)}><span className="row-title">{task.title}</span>
      <span className="row-meta">{task.id} <b>·</b> {phaseName(phases, task.phase)}{task.checklist?.length > 0 && <> <b>·</b> {task.checklist.filter(x=>x.done).length}/{task.checklist.length} pasos</>}</span>
      {!compact && task.description && <span className="row-description">{task.description}</span>}
    </button>
    <div className="row-actions"><span className={`tag priority-${task.priority}`}>{task.priority}</span>
      {task.status === 'blocked' && <span className="tag status-blocked">Bloqueada</span>}
      {task.status === 'doing' && <span className="tag status-doing">En curso</span>}
      {!done && <button className="row-quick" aria-label={task.status === 'doing' ? `Terminar ${task.title}` : `Empezar ${task.title}`} onClick={() => onStatus(task.id, task.status === 'doing' ? 'done' : 'doing')}>
        {task.status === 'doing' ? <Check size={15}/> : <Play size={14}/>}<span>{task.status === 'doing' ? 'Terminar' : 'Empezar'}</span></button>}
      {done && <button className="row-quick" aria-label={`Reabrir ${task.title}`} onClick={() => onStatus(task.id, 'todo')}><RotateCcw size={15}/><span>Reabrir</span></button>}
      <button className="row-open" onClick={() => onEdit(task)} aria-label={`Abrir ${task.title}`}><ArrowUpRight size={17}/></button>
    </div>
  </article>;
}
