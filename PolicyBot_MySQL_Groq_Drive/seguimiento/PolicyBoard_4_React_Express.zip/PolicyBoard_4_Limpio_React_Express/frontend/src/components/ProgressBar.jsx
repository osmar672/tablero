export default function ProgressBar({ value = 0, className = '' }) {
  return <div className={`progress-track ${className}`} role="progressbar" aria-valuenow={value} aria-valuemin="0" aria-valuemax="100">
    <span style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
  </div>;
}
