const URL_BASE = '/api';
async function request(path, options = {}) {
  let response;
  try {
    response = await fetch(`${URL_BASE}${path}`, {
      ...options,
      headers: { 'Content-Type': 'application/json', ...options.headers },
    });
  } catch {
    throw new Error('No hay conexión con el backend. Comprueba que Node.js esté ejecutándose.');
  }
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `Error HTTP ${response.status}`);
  return data;
}
const json = (data) => JSON.stringify(data);
export const api = {
  bootstrap: () => request('/bootstrap'),
  createTask: (data) => request('/tasks', { method: 'POST', body: json(data) }),
  updateTask: (id, data) => request(`/tasks/${encodeURIComponent(id)}`, { method: 'PATCH', body: json(data) }),
  removeTask: (id) => request(`/tasks/${encodeURIComponent(id)}`, { method: 'DELETE' }),
  updateTest: (id, data) => request(`/tests/${encodeURIComponent(id)}`, { method: 'PATCH', body: json(data) }),
  updateDeliverable: (id, data) => request(`/deliverables/${encodeURIComponent(id)}`, { method: 'PATCH', body: json(data) }),
  importBackup: (data) => request('/backup/import', { method: 'POST', body: json(data) }),
  reset: () => request('/reset', { method: 'POST', body: json({ confirm: true }) }),
};
